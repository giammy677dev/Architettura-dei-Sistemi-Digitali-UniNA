cmake --build build --target create_control_store
cmake --build build --target create_ram
cmake --build build --target check
