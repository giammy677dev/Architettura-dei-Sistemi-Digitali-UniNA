# amic-0

[![Build Status](https://travis-ci.com/albmoriconi/amic-0.svg?token=YSE4xmZpZB4FSHR7YHVu&branch=master)](https://travis-ci.com/albmoriconi/amic-0)
[![Made with Spacemacs](https://cdn.rawgit.com/syl20bnr/spacemacs/442d025779da2f62fc86c2082703697714db6514/assets/spacemacs-badge.svg)](http://www.spacemacs.org)

## Why amic-0?

The project started as an approximate computing architecture based on the
[Mic-1](https://en.wikipedia.org/wiki/MIC-1) processor design, and the name
sticked.

## Is there a detailed README?

Not yet; however, you can refer to the [lesson
notes](https://github.com/albmoriconi/dispensa-mic) (in Italian) for details on
the architecture and build instructions.
